import { useEffect, useState } from "react";

const ACTIONS = ["View", "Reply"];
const PAGE_TITLE = "Search Results";
const ERROR_MESSAGE = "Uh Oh! Something unexpected happened. Try Again.";
const LOADING_MESSAGE = "Loading ...";
const LOCALE = "en-AU";
const CURRENCY_FORMAT = "AUD";
const FORMAT_STYLE = "currency";
const FRACTION_DIGITS = 0;

const formatAsCurrency = (int) =>
  isNaN(int)
    ? int
    : new Intl.NumberFormat(LOCALE, {
        style: FORMAT_STYLE,
        currency: CURRENCY_FORMAT,
        minimumFractionDigits: FRACTION_DIGITS,
      }).format(int);

const getTitle = (length, keyword, location) => (
  <>
    <div className="listings__header__title">{PAGE_TITLE}</div>
    <div className="listings__header__subtitle">
      {`${length} results `}
      <span className="listings__header__subtitle__text">for</span>
      {` ${keyword} `}
      <span className="listings__header__subtitle__text">in</span>
      {` ${location} `}
    </div>
  </>
);

const Listing = (props) => {
  const {
    result: { title, price, location, imgUrl, description },
  } = props;

  const handleClick = (action, actionTitle) =>
    console.log(`${action}: ${actionTitle}`);

  return (
    <div className="listing">
      <div className="listing__title"> {title} </div>
      <div className="listing__subtitle">
        <div className="listing__subtitle__price">
          {formatAsCurrency(price)}
        </div>
        <div className="listing__subtitle__location">{location}</div>
      </div>
      {imgUrl && (
        <div className="listing__image">
          <img src={imgUrl} />
        </div>
      )}
      <div className="listing__description">{description}</div>
      <div className="listing__actions">
        {ACTIONS.map((action, index) => (
          <div
            key={`${title}_${index}_${action}`}
            className="listing__actions__btn"
            onClick={() => handleClick(action, title)}
          >
            {action}
          </div>
        ))}
      </div>
    </div>
  );
};

const Listings = (props) => {
  const [searchResults, setSearchResults] = useState([]);
  const [error, setError] = useState();
  const [loading, setLoading] = useState(false);
  const { dataEndpoint, keyword, location } = props;

  useEffect(() => {
    setLoading(true);
    fetch(dataEndpoint)
      .then((response) => response.json())
      .then((data) => {
        setSearchResults(data);
        setLoading(false);
      })
      .catch((err) => {
        setLoading(false);
        setError(err);
      });
  }, []);

  if (loading) {
    return <div> {LOADING_MESSAGE} </div>;
  }

  if (error) {
    return <div> {ERROR_MESSAGE} </div>;
  }

  return (
    <div>
      <div className="listings__header">
        {getTitle(searchResults.length, keyword, location)}
      </div>
      <div className="listings__grid">
        {searchResults.map((result, index) => (
          <Listing result={result} key={`${index}_${result.title}`} />
        ))}
      </div>
    </div>
  );
};

export default Listings;
