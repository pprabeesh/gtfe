module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./pages/api/listings.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./pages/api/listings.js":
/*!*******************************!*\
  !*** ./pages/api/listings.js ***!
  \*******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\nvar shuffle = __webpack_require__(/*! shuffle-array */ \"shuffle-array\");\n\nconst data = [{\n  title: \"2005 Ferrari F430 Convertible\",\n  description: \"We are proud to offer one of the rarest modern-day Ferrari's in existence today.There are only approximately 130 RIGHT HAND DRIVE 6 SPEED GATED MANUAL F430 SPIDERS IN THE WORLD\",\n  imgUrl: \"/img/ferrari01.webp\",\n  price: 299999,\n  location: \"Sydney, NSW\"\n}, {\n  title: \"2006 Ferrari F430 Spider Black 6 Speed Formula One Convertible\",\n  description: \"Traralgon Car City is located in Victoria, 1.5 hrs from Melbourne down the South Eastern freeway. We are the largest non-franchise dealership in the Gippsland Region, locally owned and operated for over 30 years. Our team have the knowledge and the expertise to help you find the right car to perfectly suit your needs.\",\n  imgUrl: \"/img/ferrari02.webp\",\n  price: 249990,\n  location: \"Taralgon, VIC\"\n}, {\n  title: \"2000 Ferrari 360 Modena F1 Blue 6 Speed Seq Manual Auto-Clutch Coupe\",\n  description: \"This Magnificent car is one for the collector, becoming harder to find in this condition this is definitely a rare car. It has always been serviced and maintained by Ferrari by its single owner and has undoubtedly been loved. It has its genuine\",\n  imgUrl: \"/img/ferrari03.webp\",\n  price: 148888,\n  location: \"Perth, WA\"\n}, {\n  title: \"1979 Ferrari 308 GTB Red 5 Speed Manual Coupe\",\n  description: \"1979 Australian Delivered Ferrari 308 GTB in the World Famous Rosso Corsa Red with Black Leather Trim - Matching Numbers 2.9L V8 Engine - Classic 5 Speed Manual Gated Transmission - Very low 40,817KMs\",\n  imgUrl: \"/img/ferrari04.webp\",\n  price: 179990,\n  location: \"Hobart, TAS\"\n}, {\n  title: \"1997 Ferrari F355 GTS Manual Coupe\",\n  description: \"For sales this beautiful rare F355 GTS 6 speed manual gearbox is in outstanding and perfect original condition, full Ferrari service history, only 1000km, done since last service, fully documented service history.\",\n  imgUrl: \"/img/ferrari05.webp\",\n  price: 200000,\n  location: \"Sydney, NSW\"\n}, {\n  title: \"Ferrari spare parts\",\n  description: \"Wanted to buy: spare parts for my Ferrari. Will travel to inspect\",\n  price: \"Wanted\",\n  location: \"Adelaide, SA\"\n}];\n/* harmony default export */ __webpack_exports__[\"default\"] = ((req, res) => {\n  const remove = Math.floor(Math.random() * Math.floor(6));\n  const response = shuffle(data, {\n    copy: true\n  }).splice(0, remove);\n  res.statusCode = 200;\n  res.json(response);\n});//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9wYWdlcy9hcGkvbGlzdGluZ3MuanM/MTg2ZSJdLCJuYW1lcyI6WyJzaHVmZmxlIiwicmVxdWlyZSIsImRhdGEiLCJ0aXRsZSIsImRlc2NyaXB0aW9uIiwiaW1nVXJsIiwicHJpY2UiLCJsb2NhdGlvbiIsInJlcSIsInJlcyIsInJlbW92ZSIsIk1hdGgiLCJmbG9vciIsInJhbmRvbSIsInJlc3BvbnNlIiwiY29weSIsInNwbGljZSIsInN0YXR1c0NvZGUiLCJqc29uIl0sIm1hcHBpbmdzIjoiQUFBQTtBQUFBLElBQUlBLE9BQU8sR0FBR0MsbUJBQU8sQ0FBQyxvQ0FBRCxDQUFyQjs7QUFFQSxNQUFNQyxJQUFJLEdBQUcsQ0FDWDtBQUNFQyxPQUFLLEVBQUUsK0JBRFQ7QUFFRUMsYUFBVyxFQUNULGtMQUhKO0FBSUVDLFFBQU0sRUFBRSxxQkFKVjtBQUtFQyxPQUFLLEVBQUUsTUFMVDtBQU1FQyxVQUFRLEVBQUU7QUFOWixDQURXLEVBU1g7QUFDRUosT0FBSyxFQUFFLGdFQURUO0FBRUVDLGFBQVcsRUFDVCxpVUFISjtBQUlFQyxRQUFNLEVBQUUscUJBSlY7QUFLRUMsT0FBSyxFQUFFLE1BTFQ7QUFNRUMsVUFBUSxFQUFFO0FBTlosQ0FUVyxFQWlCWDtBQUNFSixPQUFLLEVBQ0gsc0VBRko7QUFHRUMsYUFBVyxFQUNULHNQQUpKO0FBS0VDLFFBQU0sRUFBRSxxQkFMVjtBQU1FQyxPQUFLLEVBQUUsTUFOVDtBQU9FQyxVQUFRLEVBQUU7QUFQWixDQWpCVyxFQTBCWDtBQUNFSixPQUFLLEVBQUUsK0NBRFQ7QUFFRUMsYUFBVyxFQUNULDBNQUhKO0FBSUVDLFFBQU0sRUFBRSxxQkFKVjtBQUtFQyxPQUFLLEVBQUUsTUFMVDtBQU1FQyxVQUFRLEVBQUU7QUFOWixDQTFCVyxFQWtDWDtBQUNFSixPQUFLLEVBQUUsb0NBRFQ7QUFFRUMsYUFBVyxFQUNULHVOQUhKO0FBSUVDLFFBQU0sRUFBRSxxQkFKVjtBQUtFQyxPQUFLLEVBQUUsTUFMVDtBQU1FQyxVQUFRLEVBQUU7QUFOWixDQWxDVyxFQTBDWDtBQUNFSixPQUFLLEVBQUUscUJBRFQ7QUFFRUMsYUFBVyxFQUNULG1FQUhKO0FBSUVFLE9BQUssRUFBRSxRQUpUO0FBS0VDLFVBQVEsRUFBRTtBQUxaLENBMUNXLENBQWI7QUFtRGUsZ0VBQUNDLEdBQUQsRUFBTUMsR0FBTixLQUFjO0FBQzNCLFFBQU1DLE1BQU0sR0FBR0MsSUFBSSxDQUFDQyxLQUFMLENBQVdELElBQUksQ0FBQ0UsTUFBTCxLQUFnQkYsSUFBSSxDQUFDQyxLQUFMLENBQVcsQ0FBWCxDQUEzQixDQUFmO0FBQ0EsUUFBTUUsUUFBUSxHQUFHZCxPQUFPLENBQUNFLElBQUQsRUFBTztBQUFFYSxRQUFJLEVBQUU7QUFBUixHQUFQLENBQVAsQ0FBOEJDLE1BQTlCLENBQXFDLENBQXJDLEVBQXdDTixNQUF4QyxDQUFqQjtBQUVBRCxLQUFHLENBQUNRLFVBQUosR0FBaUIsR0FBakI7QUFDQVIsS0FBRyxDQUFDUyxJQUFKLENBQVNKLFFBQVQ7QUFDRCxDQU5EIiwiZmlsZSI6Ii4vcGFnZXMvYXBpL2xpc3RpbmdzLmpzLmpzIiwic291cmNlc0NvbnRlbnQiOlsidmFyIHNodWZmbGUgPSByZXF1aXJlKFwic2h1ZmZsZS1hcnJheVwiKTtcblxuY29uc3QgZGF0YSA9IFtcbiAge1xuICAgIHRpdGxlOiBcIjIwMDUgRmVycmFyaSBGNDMwIENvbnZlcnRpYmxlXCIsXG4gICAgZGVzY3JpcHRpb246XG4gICAgICBcIldlIGFyZSBwcm91ZCB0byBvZmZlciBvbmUgb2YgdGhlIHJhcmVzdCBtb2Rlcm4tZGF5IEZlcnJhcmkncyBpbiBleGlzdGVuY2UgdG9kYXkuVGhlcmUgYXJlIG9ubHkgYXBwcm94aW1hdGVseSAxMzAgUklHSFQgSEFORCBEUklWRSA2IFNQRUVEIEdBVEVEIE1BTlVBTCBGNDMwIFNQSURFUlMgSU4gVEhFIFdPUkxEXCIsXG4gICAgaW1nVXJsOiBcIi9pbWcvZmVycmFyaTAxLndlYnBcIixcbiAgICBwcmljZTogMjk5OTk5LFxuICAgIGxvY2F0aW9uOiBcIlN5ZG5leSwgTlNXXCIsXG4gIH0sXG4gIHtcbiAgICB0aXRsZTogXCIyMDA2IEZlcnJhcmkgRjQzMCBTcGlkZXIgQmxhY2sgNiBTcGVlZCBGb3JtdWxhIE9uZSBDb252ZXJ0aWJsZVwiLFxuICAgIGRlc2NyaXB0aW9uOlxuICAgICAgXCJUcmFyYWxnb24gQ2FyIENpdHkgaXMgbG9jYXRlZCBpbiBWaWN0b3JpYSwgMS41IGhycyBmcm9tIE1lbGJvdXJuZSBkb3duIHRoZSBTb3V0aCBFYXN0ZXJuIGZyZWV3YXkuIFdlIGFyZSB0aGUgbGFyZ2VzdCBub24tZnJhbmNoaXNlIGRlYWxlcnNoaXAgaW4gdGhlIEdpcHBzbGFuZCBSZWdpb24sIGxvY2FsbHkgb3duZWQgYW5kIG9wZXJhdGVkIGZvciBvdmVyIDMwIHllYXJzLiBPdXIgdGVhbSBoYXZlIHRoZSBrbm93bGVkZ2UgYW5kIHRoZSBleHBlcnRpc2UgdG8gaGVscCB5b3UgZmluZCB0aGUgcmlnaHQgY2FyIHRvIHBlcmZlY3RseSBzdWl0IHlvdXIgbmVlZHMuXCIsXG4gICAgaW1nVXJsOiBcIi9pbWcvZmVycmFyaTAyLndlYnBcIixcbiAgICBwcmljZTogMjQ5OTkwLFxuICAgIGxvY2F0aW9uOiBcIlRhcmFsZ29uLCBWSUNcIixcbiAgfSxcbiAge1xuICAgIHRpdGxlOlxuICAgICAgXCIyMDAwIEZlcnJhcmkgMzYwIE1vZGVuYSBGMSBCbHVlIDYgU3BlZWQgU2VxIE1hbnVhbCBBdXRvLUNsdXRjaCBDb3VwZVwiLFxuICAgIGRlc2NyaXB0aW9uOlxuICAgICAgXCJUaGlzIE1hZ25pZmljZW50IGNhciBpcyBvbmUgZm9yIHRoZSBjb2xsZWN0b3IsIGJlY29taW5nIGhhcmRlciB0byBmaW5kIGluIHRoaXMgY29uZGl0aW9uIHRoaXMgaXMgZGVmaW5pdGVseSBhIHJhcmUgY2FyLiBJdCBoYXMgYWx3YXlzIGJlZW4gc2VydmljZWQgYW5kIG1haW50YWluZWQgYnkgRmVycmFyaSBieSBpdHMgc2luZ2xlIG93bmVyIGFuZCBoYXMgdW5kb3VidGVkbHkgYmVlbiBsb3ZlZC4gSXQgaGFzIGl0cyBnZW51aW5lXCIsXG4gICAgaW1nVXJsOiBcIi9pbWcvZmVycmFyaTAzLndlYnBcIixcbiAgICBwcmljZTogMTQ4ODg4LFxuICAgIGxvY2F0aW9uOiBcIlBlcnRoLCBXQVwiLFxuICB9LFxuICB7XG4gICAgdGl0bGU6IFwiMTk3OSBGZXJyYXJpIDMwOCBHVEIgUmVkIDUgU3BlZWQgTWFudWFsIENvdXBlXCIsXG4gICAgZGVzY3JpcHRpb246XG4gICAgICBcIjE5NzkgQXVzdHJhbGlhbiBEZWxpdmVyZWQgRmVycmFyaSAzMDggR1RCIGluIHRoZSBXb3JsZCBGYW1vdXMgUm9zc28gQ29yc2EgUmVkIHdpdGggQmxhY2sgTGVhdGhlciBUcmltIC0gTWF0Y2hpbmcgTnVtYmVycyAyLjlMIFY4IEVuZ2luZSAtIENsYXNzaWMgNSBTcGVlZCBNYW51YWwgR2F0ZWQgVHJhbnNtaXNzaW9uIC0gVmVyeSBsb3cgNDAsODE3S01zXCIsXG4gICAgaW1nVXJsOiBcIi9pbWcvZmVycmFyaTA0LndlYnBcIixcbiAgICBwcmljZTogMTc5OTkwLFxuICAgIGxvY2F0aW9uOiBcIkhvYmFydCwgVEFTXCIsXG4gIH0sXG4gIHtcbiAgICB0aXRsZTogXCIxOTk3IEZlcnJhcmkgRjM1NSBHVFMgTWFudWFsIENvdXBlXCIsXG4gICAgZGVzY3JpcHRpb246XG4gICAgICBcIkZvciBzYWxlcyB0aGlzIGJlYXV0aWZ1bCByYXJlIEYzNTUgR1RTIDYgc3BlZWQgbWFudWFsIGdlYXJib3ggaXMgaW4gb3V0c3RhbmRpbmcgYW5kIHBlcmZlY3Qgb3JpZ2luYWwgY29uZGl0aW9uLCBmdWxsIEZlcnJhcmkgc2VydmljZSBoaXN0b3J5LCBvbmx5IDEwMDBrbSwgZG9uZSBzaW5jZSBsYXN0IHNlcnZpY2UsIGZ1bGx5IGRvY3VtZW50ZWQgc2VydmljZSBoaXN0b3J5LlwiLFxuICAgIGltZ1VybDogXCIvaW1nL2ZlcnJhcmkwNS53ZWJwXCIsXG4gICAgcHJpY2U6IDIwMDAwMCxcbiAgICBsb2NhdGlvbjogXCJTeWRuZXksIE5TV1wiLFxuICB9LFxuICB7XG4gICAgdGl0bGU6IFwiRmVycmFyaSBzcGFyZSBwYXJ0c1wiLFxuICAgIGRlc2NyaXB0aW9uOlxuICAgICAgXCJXYW50ZWQgdG8gYnV5OiBzcGFyZSBwYXJ0cyBmb3IgbXkgRmVycmFyaS4gV2lsbCB0cmF2ZWwgdG8gaW5zcGVjdFwiLFxuICAgIHByaWNlOiBcIldhbnRlZFwiLFxuICAgIGxvY2F0aW9uOiBcIkFkZWxhaWRlLCBTQVwiLFxuICB9LFxuXTtcblxuZXhwb3J0IGRlZmF1bHQgKHJlcSwgcmVzKSA9PiB7XG4gIGNvbnN0IHJlbW92ZSA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIE1hdGguZmxvb3IoNikpO1xuICBjb25zdCByZXNwb25zZSA9IHNodWZmbGUoZGF0YSwgeyBjb3B5OiB0cnVlIH0pLnNwbGljZSgwLCByZW1vdmUpO1xuXG4gIHJlcy5zdGF0dXNDb2RlID0gMjAwO1xuICByZXMuanNvbihyZXNwb25zZSk7XG59O1xuIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/api/listings.js\n");

/***/ }),

/***/ "shuffle-array":
/*!********************************!*\
  !*** external "shuffle-array" ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("module.exports = require(\"shuffle-array\");//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJzaHVmZmxlLWFycmF5XCI/OWRlMSJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSIsImZpbGUiOiJzaHVmZmxlLWFycmF5LmpzIiwic291cmNlc0NvbnRlbnQiOlsibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwic2h1ZmZsZS1hcnJheVwiKTsiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///shuffle-array\n");

/***/ })

/******/ });