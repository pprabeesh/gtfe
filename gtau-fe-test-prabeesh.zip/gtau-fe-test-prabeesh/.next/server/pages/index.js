module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./pages/index.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./components/Listings.js":
/*!********************************!*\
  !*** ./components/Listings.js ***!
  \********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\nvar _jsxFileName = \"/Users/pprabeesh/code/gtau-fe-test/components/Listings.js\";\n\nvar __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;\n\nconst ACTIONS = [\"View\", \"Reply\"];\nconst PAGE_TITLE = \"Search Results\";\nconst ERROR_MESSAGE = \"Uh Oh! Something unexpected happened. Try Again.\";\nconst LOADING_MESSAGE = \"Loading ...\";\nconst LOCALE = \"en-AU\";\nconst CURRENCY_FORMAT = \"AUD\";\nconst FORMAT_STYLE = \"currency\";\nconst FRACTION_DIGITS = 0;\n\nconst formatAsCurrency = int => isNaN(int) ? int : new Intl.NumberFormat(LOCALE, {\n  style: FORMAT_STYLE,\n  currency: CURRENCY_FORMAT,\n  minimumFractionDigits: FRACTION_DIGITS\n}).format(int);\n\nconst getTitle = (length, keyword, location) => __jsx(react__WEBPACK_IMPORTED_MODULE_0___default.a.Fragment, null, __jsx(\"div\", {\n  className: \"listings__header__title\",\n  __self: undefined,\n  __source: {\n    fileName: _jsxFileName,\n    lineNumber: 23,\n    columnNumber: 5\n  }\n}, PAGE_TITLE), __jsx(\"div\", {\n  className: \"listings__header__subtitle\",\n  __self: undefined,\n  __source: {\n    fileName: _jsxFileName,\n    lineNumber: 24,\n    columnNumber: 5\n  }\n}, `${length} results `, __jsx(\"span\", {\n  className: \"listings__header__subtitle__text\",\n  __self: undefined,\n  __source: {\n    fileName: _jsxFileName,\n    lineNumber: 26,\n    columnNumber: 7\n  }\n}, \"for\"), ` ${keyword} `, __jsx(\"span\", {\n  className: \"listings__header__subtitle__text\",\n  __self: undefined,\n  __source: {\n    fileName: _jsxFileName,\n    lineNumber: 28,\n    columnNumber: 7\n  }\n}, \"in\"), ` ${location} `));\n\nconst Listing = props => {\n  const {\n    result: {\n      title,\n      price,\n      location,\n      imgUrl,\n      description\n    }\n  } = props;\n\n  const handleClick = (action, actionTitle) => console.log(`${action}: ${actionTitle}`);\n\n  return __jsx(\"div\", {\n    className: \"listing\",\n    __self: undefined,\n    __source: {\n      fileName: _jsxFileName,\n      lineNumber: 43,\n      columnNumber: 5\n    }\n  }, __jsx(\"div\", {\n    className: \"listing__title\",\n    __self: undefined,\n    __source: {\n      fileName: _jsxFileName,\n      lineNumber: 44,\n      columnNumber: 7\n    }\n  }, \" \", title, \" \"), __jsx(\"div\", {\n    className: \"listing__subtitle\",\n    __self: undefined,\n    __source: {\n      fileName: _jsxFileName,\n      lineNumber: 45,\n      columnNumber: 7\n    }\n  }, __jsx(\"div\", {\n    className: \"listing__subtitle__price\",\n    __self: undefined,\n    __source: {\n      fileName: _jsxFileName,\n      lineNumber: 46,\n      columnNumber: 9\n    }\n  }, formatAsCurrency(price)), __jsx(\"div\", {\n    className: \"listing__subtitle__location\",\n    __self: undefined,\n    __source: {\n      fileName: _jsxFileName,\n      lineNumber: 49,\n      columnNumber: 9\n    }\n  }, location)), imgUrl && __jsx(\"div\", {\n    className: \"listing__image\",\n    __self: undefined,\n    __source: {\n      fileName: _jsxFileName,\n      lineNumber: 52,\n      columnNumber: 9\n    }\n  }, __jsx(\"img\", {\n    src: imgUrl,\n    __self: undefined,\n    __source: {\n      fileName: _jsxFileName,\n      lineNumber: 53,\n      columnNumber: 11\n    }\n  })), __jsx(\"div\", {\n    className: \"listing__description\",\n    __self: undefined,\n    __source: {\n      fileName: _jsxFileName,\n      lineNumber: 56,\n      columnNumber: 7\n    }\n  }, description), __jsx(\"div\", {\n    className: \"listing__actions\",\n    __self: undefined,\n    __source: {\n      fileName: _jsxFileName,\n      lineNumber: 57,\n      columnNumber: 7\n    }\n  }, ACTIONS.map((action, index) => __jsx(\"div\", {\n    key: `${title}_${index}_${action}`,\n    className: \"listing__actions__btn\",\n    onClick: () => handleClick(action, title),\n    __self: undefined,\n    __source: {\n      fileName: _jsxFileName,\n      lineNumber: 59,\n      columnNumber: 11\n    }\n  }, action))));\n};\n\nconst Listings = props => {\n  const {\n    0: searchResults,\n    1: setSearchResults\n  } = Object(react__WEBPACK_IMPORTED_MODULE_0__[\"useState\"])([]);\n  const {\n    0: error,\n    1: setError\n  } = Object(react__WEBPACK_IMPORTED_MODULE_0__[\"useState\"])();\n  const {\n    0: loading,\n    1: setLoading\n  } = Object(react__WEBPACK_IMPORTED_MODULE_0__[\"useState\"])(false);\n  const {\n    dataEndpoint,\n    keyword,\n    location\n  } = props;\n  Object(react__WEBPACK_IMPORTED_MODULE_0__[\"useEffect\"])(() => {\n    setLoading(true);\n    fetch(dataEndpoint).then(response => response.json()).then(data => {\n      setSearchResults(data);\n      setLoading(false);\n    }).catch(err => {\n      setLoading(false);\n      setError(err);\n    });\n  }, []);\n\n  if (loading) {\n    return __jsx(\"div\", {\n      __self: undefined,\n      __source: {\n        fileName: _jsxFileName,\n        lineNumber: 93,\n        columnNumber: 12\n      }\n    }, \" \", LOADING_MESSAGE, \" \");\n  }\n\n  if (error) {\n    return __jsx(\"div\", {\n      __self: undefined,\n      __source: {\n        fileName: _jsxFileName,\n        lineNumber: 97,\n        columnNumber: 12\n      }\n    }, \" \", ERROR_MESSAGE, \" \");\n  }\n\n  return __jsx(\"div\", {\n    __self: undefined,\n    __source: {\n      fileName: _jsxFileName,\n      lineNumber: 101,\n      columnNumber: 5\n    }\n  }, __jsx(\"div\", {\n    className: \"listings__header\",\n    __self: undefined,\n    __source: {\n      fileName: _jsxFileName,\n      lineNumber: 102,\n      columnNumber: 7\n    }\n  }, getTitle(searchResults.length, keyword, location)), __jsx(\"div\", {\n    className: \"listings__grid\",\n    __self: undefined,\n    __source: {\n      fileName: _jsxFileName,\n      lineNumber: 105,\n      columnNumber: 7\n    }\n  }, searchResults.map((result, index) => __jsx(Listing, {\n    result: result,\n    key: `${index}_${result.title}`,\n    __self: undefined,\n    __source: {\n      fileName: _jsxFileName,\n      lineNumber: 107,\n      columnNumber: 11\n    }\n  }))));\n};\n\n/* harmony default export */ __webpack_exports__[\"default\"] = (Listings);//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9jb21wb25lbnRzL0xpc3RpbmdzLmpzP2Y1NzEiXSwibmFtZXMiOlsiQUNUSU9OUyIsIlBBR0VfVElUTEUiLCJFUlJPUl9NRVNTQUdFIiwiTE9BRElOR19NRVNTQUdFIiwiTE9DQUxFIiwiQ1VSUkVOQ1lfRk9STUFUIiwiRk9STUFUX1NUWUxFIiwiRlJBQ1RJT05fRElHSVRTIiwiZm9ybWF0QXNDdXJyZW5jeSIsImludCIsImlzTmFOIiwiSW50bCIsIk51bWJlckZvcm1hdCIsInN0eWxlIiwiY3VycmVuY3kiLCJtaW5pbXVtRnJhY3Rpb25EaWdpdHMiLCJmb3JtYXQiLCJnZXRUaXRsZSIsImxlbmd0aCIsImtleXdvcmQiLCJsb2NhdGlvbiIsIkxpc3RpbmciLCJwcm9wcyIsInJlc3VsdCIsInRpdGxlIiwicHJpY2UiLCJpbWdVcmwiLCJkZXNjcmlwdGlvbiIsImhhbmRsZUNsaWNrIiwiYWN0aW9uIiwiYWN0aW9uVGl0bGUiLCJjb25zb2xlIiwibG9nIiwibWFwIiwiaW5kZXgiLCJMaXN0aW5ncyIsInNlYXJjaFJlc3VsdHMiLCJzZXRTZWFyY2hSZXN1bHRzIiwidXNlU3RhdGUiLCJlcnJvciIsInNldEVycm9yIiwibG9hZGluZyIsInNldExvYWRpbmciLCJkYXRhRW5kcG9pbnQiLCJ1c2VFZmZlY3QiLCJmZXRjaCIsInRoZW4iLCJyZXNwb25zZSIsImpzb24iLCJkYXRhIiwiY2F0Y2giLCJlcnIiXSwibWFwcGluZ3MiOiI7Ozs7OztBQUFBO0FBRUEsTUFBTUEsT0FBTyxHQUFHLENBQUMsTUFBRCxFQUFTLE9BQVQsQ0FBaEI7QUFDQSxNQUFNQyxVQUFVLEdBQUcsZ0JBQW5CO0FBQ0EsTUFBTUMsYUFBYSxHQUFHLGtEQUF0QjtBQUNBLE1BQU1DLGVBQWUsR0FBRyxhQUF4QjtBQUNBLE1BQU1DLE1BQU0sR0FBRyxPQUFmO0FBQ0EsTUFBTUMsZUFBZSxHQUFHLEtBQXhCO0FBQ0EsTUFBTUMsWUFBWSxHQUFHLFVBQXJCO0FBQ0EsTUFBTUMsZUFBZSxHQUFHLENBQXhCOztBQUVBLE1BQU1DLGdCQUFnQixHQUFJQyxHQUFELElBQ3ZCQyxLQUFLLENBQUNELEdBQUQsQ0FBTCxHQUNJQSxHQURKLEdBRUksSUFBSUUsSUFBSSxDQUFDQyxZQUFULENBQXNCUixNQUF0QixFQUE4QjtBQUM1QlMsT0FBSyxFQUFFUCxZQURxQjtBQUU1QlEsVUFBUSxFQUFFVCxlQUZrQjtBQUc1QlUsdUJBQXFCLEVBQUVSO0FBSEssQ0FBOUIsRUFJR1MsTUFKSCxDQUlVUCxHQUpWLENBSE47O0FBU0EsTUFBTVEsUUFBUSxHQUFHLENBQUNDLE1BQUQsRUFBU0MsT0FBVCxFQUFrQkMsUUFBbEIsS0FDZixtRUFDRTtBQUFLLFdBQVMsRUFBQyx5QkFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEdBQTBDbkIsVUFBMUMsQ0FERixFQUVFO0FBQUssV0FBUyxFQUFDLDRCQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsR0FDSSxHQUFFaUIsTUFBTyxXQURiLEVBRUU7QUFBTSxXQUFTLEVBQUMsa0NBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FGRixFQUdJLElBQUdDLE9BQVEsR0FIZixFQUlFO0FBQU0sV0FBUyxFQUFDLGtDQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSkYsRUFLSSxJQUFHQyxRQUFTLEdBTGhCLENBRkYsQ0FERjs7QUFhQSxNQUFNQyxPQUFPLEdBQUlDLEtBQUQsSUFBVztBQUN6QixRQUFNO0FBQ0pDLFVBQU0sRUFBRTtBQUFFQyxXQUFGO0FBQVNDLFdBQVQ7QUFBZ0JMLGNBQWhCO0FBQTBCTSxZQUExQjtBQUFrQ0M7QUFBbEM7QUFESixNQUVGTCxLQUZKOztBQUlBLFFBQU1NLFdBQVcsR0FBRyxDQUFDQyxNQUFELEVBQVNDLFdBQVQsS0FDbEJDLE9BQU8sQ0FBQ0MsR0FBUixDQUFhLEdBQUVILE1BQU8sS0FBSUMsV0FBWSxFQUF0QyxDQURGOztBQUdBLFNBQ0U7QUFBSyxhQUFTLEVBQUMsU0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBQ0U7QUFBSyxhQUFTLEVBQUMsZ0JBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUFrQ04sS0FBbEMsTUFERixFQUVFO0FBQUssYUFBUyxFQUFDLG1CQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FDRTtBQUFLLGFBQVMsRUFBQywwQkFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBQ0doQixnQkFBZ0IsQ0FBQ2lCLEtBQUQsQ0FEbkIsQ0FERixFQUlFO0FBQUssYUFBUyxFQUFDLDZCQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FBOENMLFFBQTlDLENBSkYsQ0FGRixFQVFHTSxNQUFNLElBQ0w7QUFBSyxhQUFTLEVBQUMsZ0JBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUNFO0FBQUssT0FBRyxFQUFFQSxNQUFWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFERixDQVRKLEVBYUU7QUFBSyxhQUFTLEVBQUMsc0JBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUF1Q0MsV0FBdkMsQ0FiRixFQWNFO0FBQUssYUFBUyxFQUFDLGtCQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FDRzNCLE9BQU8sQ0FBQ2lDLEdBQVIsQ0FBWSxDQUFDSixNQUFELEVBQVNLLEtBQVQsS0FDWDtBQUNFLE9BQUcsRUFBRyxHQUFFVixLQUFNLElBQUdVLEtBQU0sSUFBR0wsTUFBTyxFQURuQztBQUVFLGFBQVMsRUFBQyx1QkFGWjtBQUdFLFdBQU8sRUFBRSxNQUFNRCxXQUFXLENBQUNDLE1BQUQsRUFBU0wsS0FBVCxDQUg1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBS0dLLE1BTEgsQ0FERCxDQURILENBZEYsQ0FERjtBQTRCRCxDQXBDRDs7QUFzQ0EsTUFBTU0sUUFBUSxHQUFJYixLQUFELElBQVc7QUFDMUIsUUFBTTtBQUFBLE9BQUNjLGFBQUQ7QUFBQSxPQUFnQkM7QUFBaEIsTUFBb0NDLHNEQUFRLENBQUMsRUFBRCxDQUFsRDtBQUNBLFFBQU07QUFBQSxPQUFDQyxLQUFEO0FBQUEsT0FBUUM7QUFBUixNQUFvQkYsc0RBQVEsRUFBbEM7QUFDQSxRQUFNO0FBQUEsT0FBQ0csT0FBRDtBQUFBLE9BQVVDO0FBQVYsTUFBd0JKLHNEQUFRLENBQUMsS0FBRCxDQUF0QztBQUNBLFFBQU07QUFBRUssZ0JBQUY7QUFBZ0J4QixXQUFoQjtBQUF5QkM7QUFBekIsTUFBc0NFLEtBQTVDO0FBRUFzQix5REFBUyxDQUFDLE1BQU07QUFDZEYsY0FBVSxDQUFDLElBQUQsQ0FBVjtBQUNBRyxTQUFLLENBQUNGLFlBQUQsQ0FBTCxDQUNHRyxJQURILENBQ1NDLFFBQUQsSUFBY0EsUUFBUSxDQUFDQyxJQUFULEVBRHRCLEVBRUdGLElBRkgsQ0FFU0csSUFBRCxJQUFVO0FBQ2RaLHNCQUFnQixDQUFDWSxJQUFELENBQWhCO0FBQ0FQLGdCQUFVLENBQUMsS0FBRCxDQUFWO0FBQ0QsS0FMSCxFQU1HUSxLQU5ILENBTVVDLEdBQUQsSUFBUztBQUNkVCxnQkFBVSxDQUFDLEtBQUQsQ0FBVjtBQUNBRixjQUFRLENBQUNXLEdBQUQsQ0FBUjtBQUNELEtBVEg7QUFVRCxHQVpRLEVBWU4sRUFaTSxDQUFUOztBQWNBLE1BQUlWLE9BQUosRUFBYTtBQUNYLFdBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUFPdEMsZUFBUCxNQUFQO0FBQ0Q7O0FBRUQsTUFBSW9DLEtBQUosRUFBVztBQUNULFdBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUFPckMsYUFBUCxNQUFQO0FBQ0Q7O0FBRUQsU0FDRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBQ0U7QUFBSyxhQUFTLEVBQUMsa0JBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUNHZSxRQUFRLENBQUNtQixhQUFhLENBQUNsQixNQUFmLEVBQXVCQyxPQUF2QixFQUFnQ0MsUUFBaEMsQ0FEWCxDQURGLEVBSUU7QUFBSyxhQUFTLEVBQUMsZ0JBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUNHZ0IsYUFBYSxDQUFDSCxHQUFkLENBQWtCLENBQUNWLE1BQUQsRUFBU1csS0FBVCxLQUNqQixNQUFDLE9BQUQ7QUFBUyxVQUFNLEVBQUVYLE1BQWpCO0FBQXlCLE9BQUcsRUFBRyxHQUFFVyxLQUFNLElBQUdYLE1BQU0sQ0FBQ0MsS0FBTSxFQUF2RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBREQsQ0FESCxDQUpGLENBREY7QUFZRCxDQXhDRDs7QUEwQ2VXLHVFQUFmIiwiZmlsZSI6Ii4vY29tcG9uZW50cy9MaXN0aW5ncy5qcy5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcblxuY29uc3QgQUNUSU9OUyA9IFtcIlZpZXdcIiwgXCJSZXBseVwiXTtcbmNvbnN0IFBBR0VfVElUTEUgPSBcIlNlYXJjaCBSZXN1bHRzXCI7XG5jb25zdCBFUlJPUl9NRVNTQUdFID0gXCJVaCBPaCEgU29tZXRoaW5nIHVuZXhwZWN0ZWQgaGFwcGVuZWQuIFRyeSBBZ2Fpbi5cIjtcbmNvbnN0IExPQURJTkdfTUVTU0FHRSA9IFwiTG9hZGluZyAuLi5cIjtcbmNvbnN0IExPQ0FMRSA9IFwiZW4tQVVcIjtcbmNvbnN0IENVUlJFTkNZX0ZPUk1BVCA9IFwiQVVEXCI7XG5jb25zdCBGT1JNQVRfU1RZTEUgPSBcImN1cnJlbmN5XCI7XG5jb25zdCBGUkFDVElPTl9ESUdJVFMgPSAwO1xuXG5jb25zdCBmb3JtYXRBc0N1cnJlbmN5ID0gKGludCkgPT5cbiAgaXNOYU4oaW50KVxuICAgID8gaW50XG4gICAgOiBuZXcgSW50bC5OdW1iZXJGb3JtYXQoTE9DQUxFLCB7XG4gICAgICAgIHN0eWxlOiBGT1JNQVRfU1RZTEUsXG4gICAgICAgIGN1cnJlbmN5OiBDVVJSRU5DWV9GT1JNQVQsXG4gICAgICAgIG1pbmltdW1GcmFjdGlvbkRpZ2l0czogRlJBQ1RJT05fRElHSVRTLFxuICAgICAgfSkuZm9ybWF0KGludCk7XG5cbmNvbnN0IGdldFRpdGxlID0gKGxlbmd0aCwga2V5d29yZCwgbG9jYXRpb24pID0+IChcbiAgPD5cbiAgICA8ZGl2IGNsYXNzTmFtZT1cImxpc3RpbmdzX19oZWFkZXJfX3RpdGxlXCI+e1BBR0VfVElUTEV9PC9kaXY+XG4gICAgPGRpdiBjbGFzc05hbWU9XCJsaXN0aW5nc19faGVhZGVyX19zdWJ0aXRsZVwiPlxuICAgICAge2Ake2xlbmd0aH0gcmVzdWx0cyBgfVxuICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibGlzdGluZ3NfX2hlYWRlcl9fc3VidGl0bGVfX3RleHRcIj5mb3I8L3NwYW4+XG4gICAgICB7YCAke2tleXdvcmR9IGB9XG4gICAgICA8c3BhbiBjbGFzc05hbWU9XCJsaXN0aW5nc19faGVhZGVyX19zdWJ0aXRsZV9fdGV4dFwiPmluPC9zcGFuPlxuICAgICAge2AgJHtsb2NhdGlvbn0gYH1cbiAgICA8L2Rpdj5cbiAgPC8+XG4pO1xuXG5jb25zdCBMaXN0aW5nID0gKHByb3BzKSA9PiB7XG4gIGNvbnN0IHtcbiAgICByZXN1bHQ6IHsgdGl0bGUsIHByaWNlLCBsb2NhdGlvbiwgaW1nVXJsLCBkZXNjcmlwdGlvbiB9LFxuICB9ID0gcHJvcHM7XG5cbiAgY29uc3QgaGFuZGxlQ2xpY2sgPSAoYWN0aW9uLCBhY3Rpb25UaXRsZSkgPT5cbiAgICBjb25zb2xlLmxvZyhgJHthY3Rpb259OiAke2FjdGlvblRpdGxlfWApO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJsaXN0aW5nXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImxpc3RpbmdfX3RpdGxlXCI+IHt0aXRsZX0gPC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImxpc3RpbmdfX3N1YnRpdGxlXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGlzdGluZ19fc3VidGl0bGVfX3ByaWNlXCI+XG4gICAgICAgICAge2Zvcm1hdEFzQ3VycmVuY3kocHJpY2UpfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsaXN0aW5nX19zdWJ0aXRsZV9fbG9jYXRpb25cIj57bG9jYXRpb259PC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICAgIHtpbWdVcmwgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxpc3RpbmdfX2ltYWdlXCI+XG4gICAgICAgICAgPGltZyBzcmM9e2ltZ1VybH0gLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJsaXN0aW5nX19kZXNjcmlwdGlvblwiPntkZXNjcmlwdGlvbn08L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGlzdGluZ19fYWN0aW9uc1wiPlxuICAgICAgICB7QUNUSU9OUy5tYXAoKGFjdGlvbiwgaW5kZXgpID0+IChcbiAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICBrZXk9e2Ake3RpdGxlfV8ke2luZGV4fV8ke2FjdGlvbn1gfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwibGlzdGluZ19fYWN0aW9uc19fYnRuXCJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUNsaWNrKGFjdGlvbiwgdGl0bGUpfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIHthY3Rpb259XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICkpfVxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuXG5jb25zdCBMaXN0aW5ncyA9IChwcm9wcykgPT4ge1xuICBjb25zdCBbc2VhcmNoUmVzdWx0cywgc2V0U2VhcmNoUmVzdWx0c10gPSB1c2VTdGF0ZShbXSk7XG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUoKTtcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCB7IGRhdGFFbmRwb2ludCwga2V5d29yZCwgbG9jYXRpb24gfSA9IHByb3BzO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgc2V0TG9hZGluZyh0cnVlKTtcbiAgICBmZXRjaChkYXRhRW5kcG9pbnQpXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHJlc3BvbnNlLmpzb24oKSlcbiAgICAgIC50aGVuKChkYXRhKSA9PiB7XG4gICAgICAgIHNldFNlYXJjaFJlc3VsdHMoZGF0YSk7XG4gICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xuICAgICAgfSlcbiAgICAgIC5jYXRjaCgoZXJyKSA9PiB7XG4gICAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xuICAgICAgICBzZXRFcnJvcihlcnIpO1xuICAgICAgfSk7XG4gIH0sIFtdKTtcblxuICBpZiAobG9hZGluZykge1xuICAgIHJldHVybiA8ZGl2PiB7TE9BRElOR19NRVNTQUdFfSA8L2Rpdj47XG4gIH1cblxuICBpZiAoZXJyb3IpIHtcbiAgICByZXR1cm4gPGRpdj4ge0VSUk9SX01FU1NBR0V9IDwvZGl2PjtcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPGRpdj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGlzdGluZ3NfX2hlYWRlclwiPlxuICAgICAgICB7Z2V0VGl0bGUoc2VhcmNoUmVzdWx0cy5sZW5ndGgsIGtleXdvcmQsIGxvY2F0aW9uKX1cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJsaXN0aW5nc19fZ3JpZFwiPlxuICAgICAgICB7c2VhcmNoUmVzdWx0cy5tYXAoKHJlc3VsdCwgaW5kZXgpID0+IChcbiAgICAgICAgICA8TGlzdGluZyByZXN1bHQ9e3Jlc3VsdH0ga2V5PXtgJHtpbmRleH1fJHtyZXN1bHQudGl0bGV9YH0gLz5cbiAgICAgICAgKSl9XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IExpc3RpbmdzO1xuIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./components/Listings.js\n");

/***/ }),

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"default\", function() { return Home; });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/head */ \"next/head\");\n/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _components_Listings__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../components/Listings */ \"./components/Listings.js\");\nvar _jsxFileName = \"/Users/pprabeesh/code/gtau-fe-test/pages/index.js\";\n\nvar __jsx = react__WEBPACK_IMPORTED_MODULE_0___default.a.createElement;\n\n\nconst LISTINGS_ENDPOINT = \"/api/listings\";\nfunction Home() {\n  return __jsx(\"div\", {\n    className: \"home__container\",\n    __self: this,\n    __source: {\n      fileName: _jsxFileName,\n      lineNumber: 8,\n      columnNumber: 9\n    }\n  }, __jsx(next_head__WEBPACK_IMPORTED_MODULE_1___default.a, {\n    __self: this,\n    __source: {\n      fileName: _jsxFileName,\n      lineNumber: 9,\n      columnNumber: 13\n    }\n  }, __jsx(\"title\", {\n    __self: this,\n    __source: {\n      fileName: _jsxFileName,\n      lineNumber: 10,\n      columnNumber: 17\n    }\n  }, \"GTAU Front-End Test\"), __jsx(\"link\", {\n    rel: \"icon\",\n    href: \"/favicon.ico\",\n    __self: this,\n    __source: {\n      fileName: _jsxFileName,\n      lineNumber: 11,\n      columnNumber: 17\n    }\n  }), __jsx(\"link\", {\n    rel: \"stylesheet\",\n    href: \"/css/variables.css\",\n    __self: this,\n    __source: {\n      fileName: _jsxFileName,\n      lineNumber: 12,\n      columnNumber: 17\n    }\n  }), __jsx(\"link\", {\n    rel: \"stylesheet\",\n    href: \"/css/globals.css\",\n    __self: this,\n    __source: {\n      fileName: _jsxFileName,\n      lineNumber: 13,\n      columnNumber: 17\n    }\n  }), __jsx(\"link\", {\n    rel: \"stylesheet\",\n    href: \"/css/home.css\",\n    __self: this,\n    __source: {\n      fileName: _jsxFileName,\n      lineNumber: 14,\n      columnNumber: 17\n    }\n  }), __jsx(\"link\", {\n    rel: \"stylesheet\",\n    href: \"/css/listings.css\",\n    __self: this,\n    __source: {\n      fileName: _jsxFileName,\n      lineNumber: 15,\n      columnNumber: 17\n    }\n  })), __jsx(\"div\", {\n    className: \"home__content\",\n    __self: this,\n    __source: {\n      fileName: _jsxFileName,\n      lineNumber: 18,\n      columnNumber: 13\n    }\n  }, __jsx(_components_Listings__WEBPACK_IMPORTED_MODULE_2__[\"default\"], {\n    dataEndpoint: LISTINGS_ENDPOINT,\n    keyword: \"Ferrari\",\n    location: \"Australia\",\n    __self: this,\n    __source: {\n      fileName: _jsxFileName,\n      lineNumber: 19,\n      columnNumber: 17\n    }\n  })));\n}//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9wYWdlcy9pbmRleC5qcz80NGQ4Il0sIm5hbWVzIjpbIkxJU1RJTkdTX0VORFBPSU5UIiwiSG9tZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFFQSxNQUFNQSxpQkFBaUIsR0FBRyxlQUExQjtBQUVlLFNBQVNDLElBQVQsR0FBZ0I7QUFDM0IsU0FDSTtBQUFLLGFBQVMsRUFBQyxpQkFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBQ0ksTUFBQyxnREFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBQ0k7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFESixFQUVJO0FBQU0sT0FBRyxFQUFDLE1BQVY7QUFBaUIsUUFBSSxFQUFDLGNBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFGSixFQUdJO0FBQU0sT0FBRyxFQUFDLFlBQVY7QUFBdUIsUUFBSSxFQUFDLG9CQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBSEosRUFJSTtBQUFNLE9BQUcsRUFBQyxZQUFWO0FBQXVCLFFBQUksRUFBQyxrQkFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUpKLEVBS0k7QUFBTSxPQUFHLEVBQUMsWUFBVjtBQUF1QixRQUFJLEVBQUMsZUFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUxKLEVBTUk7QUFBTSxPQUFHLEVBQUMsWUFBVjtBQUF1QixRQUFJLEVBQUMsbUJBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFOSixDQURKLEVBVUk7QUFBSyxhQUFTLEVBQUMsZUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBQ0ksTUFBQyw0REFBRDtBQUNJLGdCQUFZLEVBQUVELGlCQURsQjtBQUVJLFdBQU8sRUFBQyxTQUZaO0FBR0ksWUFBUSxFQUFDLFdBSGI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQURKLENBVkosQ0FESjtBQW9CSCIsImZpbGUiOiIuL3BhZ2VzL2luZGV4LmpzLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IEhlYWQgZnJvbSBcIm5leHQvaGVhZFwiO1xuaW1wb3J0IExpc3RpbmdzIGZyb20gXCIuLi9jb21wb25lbnRzL0xpc3RpbmdzXCI7XG5cbmNvbnN0IExJU1RJTkdTX0VORFBPSU5UID0gXCIvYXBpL2xpc3RpbmdzXCI7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEhvbWUoKSB7XG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJob21lX19jb250YWluZXJcIj5cbiAgICAgICAgICAgIDxIZWFkPlxuICAgICAgICAgICAgICAgIDx0aXRsZT5HVEFVIEZyb250LUVuZCBUZXN0PC90aXRsZT5cbiAgICAgICAgICAgICAgICA8bGluayByZWw9XCJpY29uXCIgaHJlZj1cIi9mYXZpY29uLmljb1wiIC8+XG4gICAgICAgICAgICAgICAgPGxpbmsgcmVsPVwic3R5bGVzaGVldFwiIGhyZWY9XCIvY3NzL3ZhcmlhYmxlcy5jc3NcIiAvPlxuICAgICAgICAgICAgICAgIDxsaW5rIHJlbD1cInN0eWxlc2hlZXRcIiBocmVmPVwiL2Nzcy9nbG9iYWxzLmNzc1wiIC8+XG4gICAgICAgICAgICAgICAgPGxpbmsgcmVsPVwic3R5bGVzaGVldFwiIGhyZWY9XCIvY3NzL2hvbWUuY3NzXCIgLz5cbiAgICAgICAgICAgICAgICA8bGluayByZWw9XCJzdHlsZXNoZWV0XCIgaHJlZj1cIi9jc3MvbGlzdGluZ3MuY3NzXCIgLz5cbiAgICAgICAgICAgIDwvSGVhZD5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJob21lX19jb250ZW50XCI+XG4gICAgICAgICAgICAgICAgPExpc3RpbmdzXG4gICAgICAgICAgICAgICAgICAgIGRhdGFFbmRwb2ludD17TElTVElOR1NfRU5EUE9JTlR9XG4gICAgICAgICAgICAgICAgICAgIGtleXdvcmQ9XCJGZXJyYXJpXCJcbiAgICAgICAgICAgICAgICAgICAgbG9jYXRpb249XCJBdXN0cmFsaWFcIlxuICAgICAgICAgICAgICAgID48L0xpc3RpbmdzPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICk7XG59XG4iXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/index.js\n");

/***/ }),

/***/ "next/head":
/*!****************************!*\
  !*** external "next/head" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("module.exports = require(\"next/head\");//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJuZXh0L2hlYWRcIj81ZWYyIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBIiwiZmlsZSI6Im5leHQvaGVhZC5qcyIsInNvdXJjZXNDb250ZW50IjpbIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIm5leHQvaGVhZFwiKTsiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///next/head\n");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("module.exports = require(\"react\");//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJyZWFjdFwiPzU4OGUiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEiLCJmaWxlIjoicmVhY3QuanMiLCJzb3VyY2VzQ29udGVudCI6WyJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWFjdFwiKTsiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///react\n");

/***/ })

/******/ });